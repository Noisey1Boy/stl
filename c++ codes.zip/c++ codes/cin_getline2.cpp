#include<iostream>
int main()
{
    std::string name;
    int age;

    std::cout << "What's your age?" << '\n';
    std::cin >>age;
    
    std::cout << "What's your full name?" << '\n';
    std::getline(std::cin >>std::ws, name);//getline pore use korle ebhabe korte hobe
    
    std::cout << "Hello " << name << '\n';
    std::cout << "You are " << age << " years old";

    return 0;

}