#include<iostream>
int main()
{
    std::string name;
    int age;

    std::cout << "What's your name?" << '\n';
    std::cin >>name; //cin diye space soho input newa jaina

    std::cout << "What's your age?" << '\n';
    std::cin >>age;
    
    std::cout << "Hello " << name << '\n';
    std::cout << "You are " << age << " years old";

    return 0;

}