#include<iostream>

void happybirthday(std::string name , int age);

int main()
{
    std::string name = "Rangan";
    int age = 21;

    happybirthday(name , age);
    happybirthday(name , age);
    happybirthday(name , age);

    return 0;

}

void happybirthday(std::string name , int age)
{
    std::cout << "Happy birthday to " << name << '\n';
    std::cout << "Happy birthday to " << name << '\n';
    std::cout << "Happy birthday dear " << name << '\n';
    std::cout << "Happy birthday to " << name << '\n';
    std::cout << "You age " << age << " years old" << '\n';
    std::cout << '\n';
}