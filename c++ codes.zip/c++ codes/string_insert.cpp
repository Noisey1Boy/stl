#include<iostream>

int main()
{
    std::string name;

    std::cout << "Enter your name : ";
    std::getline(std::cin , name);

    name.insert(0 , "@");
    name.insert(4 , "okay");

    std::cout << name;

    return 0;

}