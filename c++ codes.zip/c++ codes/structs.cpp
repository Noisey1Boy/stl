#include<iostream>

struct students
{
    std::string name;
    double gpa;
    bool enrolled;
};

int main()
{
    students student1;
    student1.name = "Spongebob";
    student1.gpa = 3.2;
    student1.enrolled = true;

    students student2;
    student2.name = "Patrick";
    student2.gpa = 3.5;
    student2.enrolled = 1;

    std::cout << student1.name << '\n';
    std::cout << student1.gpa << '\n';
    std::cout << student1.enrolled << '\n';

    std::cout << student2.name << '\n';
    std::cout << student2.gpa << '\n';
    std::cout << student2.enrolled << '\n';

    return 0;

}