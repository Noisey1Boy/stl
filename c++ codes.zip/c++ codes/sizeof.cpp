#include<iostream>
int main()
{
        std::string name = "bro code";
        double gpa = 2.88;
        char character = 'r';
        double numbers[] = { 2 , 3 , 4 , 5 , 6 } ;

        std::cout << sizeof(gpa) << " bytes\n";
        std::cout << sizeof(gpa) << " bytes\n";
        std::cout << sizeof(character) << " bytes\n";
        std::cout << sizeof(numbers) << " bytes \n";
        std::cout << sizeof(numbers)/sizeof(numbers[0]) << " elements\n";
/* or */std::cout << sizeof(numbers)/sizeof(double) << " elements\n";

    return 0;
}