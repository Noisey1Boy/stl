#include<iostream>
int main()
{
    int correct = 8;
    int qus = 10;

    double score = correct/(double)qus * 100;

    std::cout << score << " %";

    return 0;

}