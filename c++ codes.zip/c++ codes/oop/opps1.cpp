#include<iostream> 
using namespace std;

class Teacher
{
    private :

    double salary;

    public :
    //properties / attributes
    string name;
    string dept;
    string subject;
    
    //methods / member functions
    void changeDept(string newDept)
    {
        dept = newDept;
    }
};

int main()
{
    Teacher t1;

    t1.name = "rangan";
    t1.subject = "C++";
    t1.dept = "Computer Science";
    
    cout << "name : " << t1.name << endl;
    cout << "subject : " << t1.subject << endl;
    cout << "dept : " << t1.dept << endl;

    t1.changeDept("Electrical Engineering");
    cout << "new dept : " << t1.dept << endl;

    return 0;

}