#include<iostream>
using namespace std;

class Teacher
{
    private :
    double salary; // data hiding

    
    public :
    //properties / attributes
    string name;
    string dept;
    string subject;
    
    Teacher(string n,string dept, string subject, double sal)//parameterized constructor
    {
        cout << "Hi! I am constructor-2\n"; 
        name = n;
        this -> dept = dept; //same name paprameter dile this-> use kote hobe
        this -> subject = subject; //this-> diye object er name ke inicate kore
        salary = sal;
    }

    //copy constructor
    Teacher(Teacher &orgObj) //pass by reference
    {
        cout << "I'm custom copy constructor....\n";
        this -> name = orgObj.name;
        this -> dept = orgObj.dept;
        this -> subject = orgObj.subject;
        this -> salary = orgObj.salary;
    }
    
    //methods / member functions
    void changeDept(string newDept)
    {
        dept = newDept;
    }

    //private er moddher properties er access pete setter getter use korte hobe
    void setSalary(double s) //setter
    {
        salary = s;
    }
    
    double getSalary() //getter
    {
        return salary;
    }

    void getInfo()
    {
        cout << "name : " << name << endl;
        cout << "dept : " << dept << endl;
        cout << "subject : " << subject << endl;
        cout << "salary : " << getSalary() << endl;
    }
};

int main()
{
    Teacher t1("adnan", "EEE", "Physics", 20000); //constructor call
    
    Teacher t2(t1);//custom copy constructor invoke
    //custom copy constructor create na korleo compiler nije theke default copy constructor create korbe
    //amader copy constructor create kora necessary na

    t2.getInfo();

    return 0;

}