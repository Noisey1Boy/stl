#include<iostream>
using namespace std;

class Teacher
{
    private :
    double salary; // data hiding

    
    public :
    //properties / attributes
    string name;
    string dept;
    string subject;
    
    //constructor
    //constructor ke sobshomoy public declare korte hobe
    Teacher()//non-parameterized constructor
    {
        cout << "Hi! I am constructor-1\n"; 
        dept = "Computer Science";
    }

    Teacher(string n,string dept, string subject, double sal)//parameterized constructor
    {
        cout << "Hi! I am constructor-2\n"; 
        name = n;
        this -> dept = dept; //same name paprameter dile this-> use kote hobe
        this -> subject = subject; //this-> diye object er name ke inicate kore
        salary = sal;
    }
    
    //methods / member functions
    void changeDept(string newDept)
    {
        dept = newDept;
    }

    //private er moddher properties er access pete setter getter use korte hobe
    void setSalary(double s) //setter
    {
        salary = s;
    }
    
    double getSalary() //getter
    {
        return salary;
    }

    void getInfo()
    {
        cout << "name : " << name << endl;
        cout << "dept : " << dept << endl;
        cout << "subject : " << subject << endl;
        cout << "salary : " << getSalary() << endl;
    }
};

int main()
{
    Teacher t1; //constructor call

    t1.name = "rangan";
    t1.subject = "C++"; 
    t1.setSalary(25000);

    Teacher t2("adnan", "EEE", "Physics", 20000); //constructor call

    t1.getInfo();

    t2.getInfo();

    return 0;

}