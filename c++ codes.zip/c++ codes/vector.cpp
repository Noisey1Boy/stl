#include<iostream>
#include<vector>
using namespace std;

int main()
{
    vector<int>vec; //size 0
    
    cout <<vec.size()<<endl;

    return 0;   
}
