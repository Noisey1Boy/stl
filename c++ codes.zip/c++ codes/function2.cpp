#include<iostream>

void happybirthday();

int main()
{
    happybirthday();
    happybirthday();
    happybirthday();

    return 0;

}

void happybirthday()
{
    std::cout << "happy birthday to you\n";
    std::cout << "happy birthday to you\n";
    std::cout << "happy birthday dear you\n";
    std::cout << "happy birthday to you\n\n";
}