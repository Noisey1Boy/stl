#include<iostream>

int main()
{
    std::string x = "coke";
    std::string y = "water";

    std::string temp;

    temp = x;
    x = y;
    y = temp;

    std::cout << "X : " << x << '\n';
    std::cout << "Y : " << y << '\n';
    
    return 0;
}
