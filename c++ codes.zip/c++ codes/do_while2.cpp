#include<iostream>
using namespace std;

int main()
{
    string name;
   
    do
    {
        cout << "Enter your name : ";
        getline(cin, name);

        if(!name.empty())
        {
            cout << "hello " << name << endl;
        }
    }
    while(!name.empty());

    return 0;
}