#include<iostream>

enum Day {sunday = 0, monday = 1, tuesday = 2, 
          wednesday = 3, thursday = 4,
          friday = 5, saturday = 6};

enum Flavour { vanilla , chocolate , mint};

int main()
{
    Day today = friday;

    switch(today)
    {
        case sunday : std::cout << "It is Sunday!\n";
                        break;
        case monday : std::cout << "It is Monday!\n";
                        break;
        case tuesday : std::cout << "It is TUesday!\n";
                        break;
        case wednesday : std::cout << "It is Wednesday!\n";
                        break;
        case thursday : std::cout << "It is Thursday!\n";
                        break;
        case friday : std::cout << "It is Friday!\n";
                        break;//case 5 : likhleo friday e bujhabe
        case saturday : std::cout << "It is Saturday!\n";
                        break;
        
    }

    Flavour craving = chocolate;

    switch(craving)
    {
        case vanilla : std::cout << "Flavour is Vanilla!\n";
                        break;
        case chocolate : std::cout << "Flavour is Chocolate!\n";
                        break;       
        case mint : std::cout << "Flavour is Mint!\n";
                        break;        
    }

    return 0;
}