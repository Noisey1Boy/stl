#include<iostream>

int main()
{
    //foreach loop = loop that eases the traversal over
    //               an iterable data set

    std::string students[] = {"spongebob" , "patrick" , "squidward" , "sandy"};
}