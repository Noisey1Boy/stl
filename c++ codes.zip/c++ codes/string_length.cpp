#include<iostream>
using namespace std;

int main()
{
    string name;

    cout << "Enter your name : ";
    getline(cin , name);

    if(name.length() > 12)
    {
        cout << "Your name can't be over 12 character!\n";
    }
    else
    {
        cout << "Welcome " << name << endl;
    }
    
    cout << "name length : " << name.length();

    return 0;

}