#include<iostream>
#include<ctime>
#include<limits>
using namespace std;

void numGuessingGame();

void RockPaperScissors();
char getUserChoice();
char getComputerChoice();
void showChoice(char choice);
void chooseWinner(char player , char computer);

int main()
{
    int gameChoice;
    char playAgain;
    do
    {
        do
        {
            cout << "1. Number Guessing Game\n";
            cout << "2. Rock Paper Scissors\n";
            cout << "3. Exit\n";
            cout << "which game do you want to play?(1 ,2 or 3) : ";
            cin >> gameChoice;
            
            cin.clear();
            fflush(stdin);
            
            if(gameChoice != 1 && gameChoice != 2 && gameChoice != 3)
            {
                cout << "invalid input! choose 1 ,2 or 3\n\n";
            }
        
        } while (gameChoice != 1 && gameChoice !=2 && gameChoice != 3);

        switch (gameChoice)
        {
        case 1 :
            numGuessingGame();
            break;
        case 2 :
            RockPaperScissors();
            break;
        case 3 :
            cout << "Exiting the game!!\n";
            return 0;
        }

        cout << "Do you want to play again? (y/n) : ";
        cin >> playAgain;
        
    } while(playAgain == 'y' || playAgain == 'Y');
  
    return 0;
}

void numGuessingGame()
{
    int num;
    int guess;
    int tries = 0;

    srand(time(NULL));
    num = (rand() % 6 + 1);

    cout << "*********number guessing game**********\n";

    do
    {
        cout << "enter a number between 1-100 : ";
        cin >> guess;

        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max() , '\n');
        
        tries++;

        if(guess > num)
        {
            cout << "too high!\n";
        }
        else if(guess < num)
        {
            cout << "too low!\n";
        }
        else
        {
            cout << "correct!!\n";
            cout << "number of tries : " << tries << endl;
        
            cout << "**************************************\n";     
        }
    }
    while (guess != num);

}


char getUserChoice()
{
    char choice;
    
    do
    {
    std::cout << "\n\n******************************\n";
    std::cout << "Rock - Paper - Scissors Game!!\n";
    std::cout << "******************************\n";
    std::cout << "Choose one of the following :\n";
    std::cout << "'r' for rock\n";
    std::cout << "'p' for paper\n";
    std::cout << "'s' for scissors\n";
    std::cout << "Enter your choice : ";
    std::cin >> choice;

    if(choice != 'r' && choice != 'p' && choice != 's')
    {
        std::cout << "\nInvalid choice!!\n";
    }
    }
    while(choice != 'r' && choice != 'p' && choice != 's');

    return choice;

}
char getComputerChoice()
{
    srand(time(0));

    int num = rand() % 3 + 1;

    switch(num)
    {
        case 1 : return 'r';
        case 2 : return 'p';
        case 3 : return 's';
    }
}
void showChoice(char choice)
{
    switch (choice)
    {
    case 'r' : std::cout << "Rock\n";
        break;
    case 'p' : std::cout << "Paper\n";
        break;
    case 's' : std::cout << "Scissors\n";
        break;
    }
}
void chooseWinner(char player , char computer)
{
    switch(player)
    {
        case 'r' : if(computer == 'r')
                    {
                        std::cout << "It's a tie!\n";
                    }
                    else if(computer == 'p')
                    {
                        std::cout << "You lose!\n";
                    }
                    else
                    {
                        std::cout << "You win!\n";
                    }
                    break;
        case 'p' : if(computer == 'r')
                    {
                        std::cout << "You win!\n";
                    }
                    else if(computer == 'p')
                    {
                        std::cout << "It's a tie!\n";
                    }
                    else
                    {
                        std::cout << "You lose!\n";
                    }
                    break;
        case 's' : if(computer == 'r')
                    {
                        std::cout << "You lose!\n";
                    }
                    else if(computer == 'p')
                    {
                        std::cout << "You win!\n";
                    }
                    else
                    {
                        std::cout << "It's a tie!\n";
                    }
                    break;                                
    }
}

void RockPaperScissors()
{
    char playerChoice;
    char computer;

    playerChoice = getUserChoice();
    std::cout << "Your choice : ";
    showChoice(playerChoice);

    computer = getComputerChoice();
    std::cout << "Computer choice : ";
    showChoice(computer);

    chooseWinner(playerChoice , computer);

}