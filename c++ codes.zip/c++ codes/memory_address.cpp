#include<iostream>

int main()
{
    std::string name = "rangan";
    int age = 21;

    std::cout << &name << '\n';
    std::cout << &age << '\n';

    return 0;
}