#include<iostream>
int main()
{
    int students = 20;

    //students = students + 2; output = 22
    //students+=2; output = 22
    students++; //output = 21

    std::cout << students << '\n';

    int apples = 5;

    //apples = apples - 2; output = 3
    //apples-=2; output = 3
    apples--; //output = 4

    std::cout << apples << '\n';

    int lemons = 10;

    //lemons = lemons * 2; output = 20
    lemons*=2;  //output = 20; 

    std::cout << lemons << '\n';

    int babies = 20;

    //babies = babies / 2; output = 10
    //babies /= 2; output = 10
    babies /= 3;  // output = 6

    std::cout << babies << '\n';

    int shirts = 20;
    int remainder = shirts % 3;

    std::cout << remainder << '\n';

    /*order of precedence of arithmetic operaters
    >parenthesis
    >multiplication & division
    >addition & subtraction   */

    int number = 6 - 5 + 4 * 3 /2;

    std::cout << number << '\n';

    return 0;
}
