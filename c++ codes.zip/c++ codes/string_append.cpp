#include<iostream>
using namespace std;

int main()
{
    string name;
    cout << "enter name : ";
    getline(cin, name);

    name.append("@gmail.com");

    cout << "your username is now : " << name << endl;

    return 0;
}
