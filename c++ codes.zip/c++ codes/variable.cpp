#include<iostream>

int main()
{
    int x; //declaration
    x = 5;
    int y = 6;
    int sum = x + y;
    std::cout << "x = " << x << '\n';
    std::cout << "y = " << y << '\n';
    std::cout << "sum = " << sum << '\n';

    return 0;

}