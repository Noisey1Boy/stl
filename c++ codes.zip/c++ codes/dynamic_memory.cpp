#include<iostream>

int main()
{
    int *pNum = NULL;

    pNum = new int;

    *pNum = 32;

    std::cout << "address : " << pNum << '\n';
    std::cout << "value : " << *pNum << '\n';

    delete pNum;

    return 0;
}