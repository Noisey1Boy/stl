#include<iostream>
int main()
{
    for(int i = 1; i <= 10; i++)
    { 
        std::cout << i << " Happy New Year!" << '\n';       
    }

    return 0;

}