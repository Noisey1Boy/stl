#include<iostream>

double searchArray(std::string array[] , std::string element , double size);

int main()
{
    std::string foods[] = {"pizza" , "burger" , "hotdog"};
    double size = sizeof(foods)/sizeof(double);
    double index;
    std::string myFood;

    std::cout << "Enter element to search for : ";
    std::getline(std::cin , myFood);

    index = searchArray(foods, myFood , size );

    if(index != -1)
    {
        std::cout << myFood << " is at index " << index;
    }
    else
    {
        std::cout << myFood << " is not in the array!!";
    }

    return 0;
}
double searchArray(std::string array[] , std::string element , double size )
{
    for(int i = 0; i < size; i++)
    {
        if(array[i] == element)
        {
            return i;
        }
    }
    return -1;
}