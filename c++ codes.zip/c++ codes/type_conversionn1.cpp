#include<iostream>
int main()
{
    double x = (int) 3.14;
    std::cout << x << '\n';

    char y = 100;
    std::cout << (int) y << '\n';

    char z = 100;
    std::cout << z << '\n';
    //or,
    std::cout << (char)  100<< '\n';
    

    return 0;
}