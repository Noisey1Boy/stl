#include<iostream>
#include<vector>
#include<algorithm>
using namespace std;

int main()
{
    vector<int> vec = {1, 2 , 3, 4, 5};

    cout << binary_search(vec.begin() , vec.end() , 2) << endl;
    //or
    if(binary_search(vec.begin() , vec.end() , 2))
    {
        cout << "found";
    }
    else
    {
        cout << "not found";
    }

    return 0;
}
