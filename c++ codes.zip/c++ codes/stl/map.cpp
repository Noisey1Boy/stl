#include<iostream>
#include<map>
using namespace std;

int main()
{
    map<string , int> m;

    m["tv"] = 100; //egula sorted order e print hobe
    m["tv"] = 99; /*same key duibar thakleo ekbar e print hobe
                  second bar same key insert korle prothom barer
                  key er value second barer value diye replaced hobe*/
    m["laptop"] = 120;
    m["headphone"] = 50;
    m["tablet"] = 130;
    m["watch"] = 70;
    
    for(auto p : m)
    {
        cout << p.first << " " << p.second << endl;
    }
    return 0;
}