#include<iostream>
#include<map>
using namespace std;

int main()
{
    multimap<string , int> m;

    m.insert({"tv", 90});
    m.insert({"tv", 100});

    m.emplace("tv", 282);
    m.emplace("tv", 737);
    
    //m.erase(m.find("tv"));//sudhu prothom tv key ke erase kore debe
    for(auto p : m)
    {
        cout << p.first << " " << p.second << endl;
    }

    return 0;
}