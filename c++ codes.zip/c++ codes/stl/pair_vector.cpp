#include<iostream>
#include<vector>
using namespace std;

int main()
{
    vector<pair<char,int>> vec =  {{'a', 5} , {'b' , 6} , {'c' , 9}};

    vec.push_back({'d' , 7});//push_back korte parenthesis er moddhe curly braces diye input dite hobe
    vec.emplace_back('e' , 2);//emplace_back e curly braces lagbena , in-place ojbects create kore
    
    for(pair<char, int> element : vec)
    //or for(auto element : vec) likheo element declare kora jabe
    {
        cout << element.first << " " << element.second << endl;
    }


    return 0;
}