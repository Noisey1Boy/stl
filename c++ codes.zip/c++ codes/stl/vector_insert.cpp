#include<iostream>
#include<vector>
using namespace std;

int main()
{
    vector<int> vec = {1 , 2 , 3 , 4 , 5};

    vec.insert(vec.begin() + 2 , 100);
    
    cout << "values : ";
    
    for(int value : vec)
    {
        cout << value << " ";
    }
    cout << endl;

    return 0;
}