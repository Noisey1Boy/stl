#include<iostream>
#include<unordered_set>
using namespace std;

int main()
{
    unordered_set<char> s;

    s.insert('a');
    s.insert('c');
    s.insert('b');
    s.insert('b');
    s.insert('b');
    s.insert('c');
    s.insert('d');

    for(auto val : s)
    {
        cout << val << " ";
    }
    cout << endl;

    return 0;
    
}
