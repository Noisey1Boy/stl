#include<iostream>
#include<unordered_map>
using namespace std;

int main()
{
    unordered_map<string , int> m;

    m.insert({"tv", 33});
    m.insert({"tv", 99});

    m.emplace("tv", 64);
    m.emplace("tv", 83);
    
    for(auto p : m)
    {
        cout << p.first << " " << p.second << endl;
    }

    return 0;
}