#include<iostream>
#include<queue>//first in first out
using namespace std;

int main()
{
    queue<int> q;

    q.push(1);
    q.push(2);
    q.emplace(3);
    q.emplace(4);

    q.pop(); //1 will be popped

    while(!q.empty())
    {
        cout << q.front() << " ";
        q.pop();
    }
    cout << endl;

    return 0;
    
}
