#include<iostream>
#include<set>
using namespace std;

int main()
{
    multiset<char> s;

    // Inserting elements (order doesn't matter, multiset will sort them)
    s.insert('a');
    s.insert('c');
    s.insert('b');
    s.insert('b');
    s.insert('b');
    s.insert('c');
    s.insert('d');

    // The multiset will be sorted: a b b b c c d
    // Indices:     0: a
    //              1: b
    //              2: b
    //              3: b
    //              4: c
    //              5: c
    //              6: d

    cout << "lower bound of 'b': " << *(s.lower_bound('b')) 
         << " at index: " << distance(s.begin(), s.lower_bound('b')) << endl;
    // Output: b at index 1 (first 'b')

    cout << "upper bound of 'b': " << *(s.upper_bound('b')) 
         << " at index: " << distance(s.begin(), s.upper_bound('b')) << endl;
    // Output: c at index 4 (first element after all 'b's)

    cout << "Multiset elements: ";
    for(auto val : s) {
        cout << val << " ";
    }
    cout << endl;
    // Output: a b b b c c d

    return 0;
}