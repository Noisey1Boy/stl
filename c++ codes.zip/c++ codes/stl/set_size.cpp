#include<iostream>
#include<set>
using namespace std;

int main()
{
    set<int> s;

    s.insert(1);
    s.insert(8);
    s.emplace(3);
    s.emplace(4);

    s.emplace(1); //same value duibar innput dile duibar same output deina
    s.emplace(2); //output er value sorted hobe
    s.emplace(3);

    cout << "size : " <<s.size() << endl;

    for(auto val : s)
    {
        cout << val << " ";
    }
    cout << endl;

    return 0;
}