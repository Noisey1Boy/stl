#include<iostream>
#include<set>
using namespace std;

int main()
{
    //lower bound means minimmum
    set<int> s;

    s.insert(1);
    s.insert(2);
    s.insert(3);
    s.insert(4);

    cout << "lower bound of s : " << *(s.lower_bound(3)) << endl; //3

    for(auto val : s)
    {
        cout << val << " ";
    }
    cout << endl;

    set<int> s2;

    s2.insert(4);
    s2.insert(2);
    s2.insert(9);
    s2.insert(6);

    cout << "lower bound of s2 : " << *(s2.lower_bound(3)) << endl; //4

    for(auto val : s2)
    {
        cout << val << " ";
    }
    cout << endl;

    set<int> s3;

    s3.insert(1);
    s3.insert(2);
    s3.insert(5);

    cout << "lower bound of s3 : " << *(s3.lower_bound(7)) << endl; //0

    for(auto val : s3)
    {
        cout << val << " ";
    }
    cout << endl;

    return 0;
    
}
