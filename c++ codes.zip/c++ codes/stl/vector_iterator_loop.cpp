#include<iostream>
#include<vector>
using namespace std;

int main()
{
    vector<int> vec = {1 , 2 , 3 , 4 , 5};

    cout << "values : ";
    
    vector<int>::reverse_iterator it;

    for(it = vec.rbegin(); it != vec.rend(); it++)
    {
        cout << *it << " ";
    }
    cout << endl;
    
    //or, amra auto keyword use koreo type define korte pari 
    cout << "values : ";

    for(auto it = vec.rbegin(); it != vec.rend(); it++)
    {
        cout << *it << " ";
    }
    cout << endl;

    return 0;
}