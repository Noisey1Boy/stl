#include<iostream>
#include<algorithm>
#include<vector>
using namespace std;

int main()
{
    vector<int> vec = {3, 8, 5, 2, 1};

    sort(vec.begin() + 1, vec.begin() + 3 , greater<int>()); /*will sort elements from index1 to
                              index2 ,,, index3 will not be included */
    cout << "Sorted(decending) vector elements(index_1 to index_2) : ";
    for(int val : vec)
    {
        cout << val << " ";
    }
    cout << endl;

    sort(vec.begin() , vec.end() , greater<int>());
    
    cout << "Sorted(decending) vector elements(index_0 to index_5) : ";
    for(int val : vec)
    {
        cout << val << " ";
    }
    cout << endl;

    return 0;
}