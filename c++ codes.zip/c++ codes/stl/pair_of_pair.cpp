#include<iostream>
using namespace std;

int main()
{
    pair<string, pair<char,int>> p = {"rangan", {'a', 5}};

    cout << p.first << endl;
    cout << p.second.first << endl;
    cout << p.second.second << endl;

    return 0;
}