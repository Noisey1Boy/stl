#include<iostream>
#include<list>
using namespace std;

int main()
{
    list<int> list1 = {1, 2, 3, 4, 5};
    
    cout << "List 1 elements : ";
    for(int element : list1)
    {
        cout << element << " ";
    }
    cout << endl;

    list<int> list2;

    list2.push_back(1);
    list2.emplace_back(2);

    list2.push_front(3);
    list2.emplace_front(5);

    cout << "List 2 elements before poping: ";
    for(int element : list2)
    {
        cout << element << " ";
    }
    cout << endl;

    list2.pop_back();
    list2.pop_front();

    cout << "List 2 elements after poping: ";
    for(int element : list2)
    {
        cout << element << " ";
    }
    cout << endl;

    return 0;
} 