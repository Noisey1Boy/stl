#include<iostream>
#include<map>
using namespace std;

int main()
{
    map<string , int> m;

    m["tv"] = 100; //egula sorted order e print hobe
    m["laptop"] = 120;
    m["headphone"] = 50;
    m["tablet"] = 130;
    m["watch"] = 70;
    
    m.insert({"camera" , 25});
    m.emplace("mobile", 40);

    for(auto p : m)
    {
        cout << p.first << " " << p.second << endl;
    }

    if(m.find("camera") != m.end())
    {
        cout << "found\n";
    }
    else
    {
        cout << "not found\n";
    }
    
    return 0;
}
