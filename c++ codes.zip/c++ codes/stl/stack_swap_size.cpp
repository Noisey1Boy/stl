#include<iostream>
#include<stack>//last in first out
using namespace std;

int main()
{
    stack<int> s1;

    s1.push(1);
    s1.push(2);
    s1.emplace(3);
    s1.emplace(4);

    stack<int> s2;
    
    cout << "s1 size before swapping : " << s1.size() <<endl;
    cout << "s2 size before swapping : " << s2.size() <<endl;
  
    s2.swap(s1);

    cout << "s1 size after swapping : " << s1.size() <<endl;
    cout << "s2 size after swapping : " << s2.size() <<endl;
    
    cout << "s1 elements : ";
    while(!s1.empty())
    {
        cout << s1.top() << " ";
        s1.pop();
    }
    cout << endl;
    
    cout << "s2 elements : ";
    while(!s2.empty())
    {
        cout << s2.top() << " ";
        s2.pop();
    }
    cout << endl;

    return 0;
}
