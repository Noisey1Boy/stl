#include<iostream>
#include<algorithm>
#include<vector>
using namespace std;

int main()
{
    vector<int> vec = {2, 5 ,1 , 4, 3};

    reverse(vec.begin() , vec.end()); //reverse(vec.begin()+1 , vec.begin()+3) emon o kora jabe

    for(auto val : vec)
    {
        cout << val << endl;
    }

    return 0;

}