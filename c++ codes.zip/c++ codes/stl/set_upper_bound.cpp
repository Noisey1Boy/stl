#include<iostream>
#include<set>
using namespace std;

int main()
{
    //lower bound means minimmum or <=
    //upper bound means greater than or <
    set<int> s;

    s.insert(1);
    s.insert(2);
    s.insert(3);
    s.insert(4);

    cout << "lower bound of s : " << *(s.lower_bound(3)) << endl; //3
    cout << "upper bound of s : " << *(s.upper_bound(3)) << endl; //4

    for(auto val : s)
    {
        cout << val << " ";
    }
    cout << endl;

    return 0;
    
}
