#include<iostream>
using namespace std;

int main()
{
    pair<string,int> p = {"rangan", 5};

    cout << p.first << endl;
    cout << p.second << endl;

    return 0;
}