#include<iostream>
#include<vector>
using namespace std;

int main()
{
    vector<int> vec = {1, 2, 3, 4, 5};

    cout << "size before erasing : " << vec.size() << endl;
    cout << "capacity before erasing : " << vec.capacity() << endl;

    //vec.erase(vec.begin()); //index no 0 will be erased
    //vec.erase(vec.begin() + 2); //index no 2 will be erased
    vec.erase(vec.begin() + 1 , vec.begin() + 3);//index no 1 to 2 will be erased
    //start is included but end is not included

    cout << "values : " ;

    for(int val : vec)
    {
        cout << val << " ";
    }

    cout << endl;

    //erase size change kore but capacity change korena
    cout << "size after erasing : " << vec.size() << endl;
    cout << "capacity after erasing : " << vec.capacity() << endl;

    return 0;
}