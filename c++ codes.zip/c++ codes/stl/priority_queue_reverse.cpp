#include<iostream>
#include<queue>
using namespace std;

int main()
{
    priority_queue<int, vector<int>, greater<int>> q;//largest value -> highest priority

    q.push(5);
    q.push(3);
    q.emplace(10);
    q.emplace(4);
    q.emplace(18);
   
    q.pop(); //3 will be popped

    cout << "size : " << q.size() << endl;

    cout << "priority queue elements :\n";
    while(!q.empty())
    {
        cout << q.top() << endl;
        q.pop();
    }

    return 0;
    
}
