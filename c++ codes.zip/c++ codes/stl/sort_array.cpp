#include<iostream>
#include<algorithm>
using namespace std;

int main()
{
    int arr[] = {3, 8, 5, 2, 1};

    sort(arr + 1 , arr + 3); /*will sort elements from index1 to
                              index2 ,,, index3 will not be included */
    cout << "Sorted Array elements(index_1 to index_2) : ";
    for(int val : arr)
    {
        cout << val << " ";
    }
    cout << endl;

    sort(arr , arr + 5);
    
    cout << "Sorted Array elements(index_0 to index_5) : ";
    for(int val : arr)
    {
        cout << val << " ";
    }
    cout << endl;

    return 0;
}