#include<iostream>
#include<stack>//last in first out
using namespace std;

int main()
{
    stack<int> s;

    s.push(1);
    s.push(2);
    s.emplace(3);
    s.emplace(4);

    s.pop(); //4 will be popped

    while(!s.empty())
    {
        cout << s.top() << endl;
        s.pop();
    }

    return 0;
    
}
