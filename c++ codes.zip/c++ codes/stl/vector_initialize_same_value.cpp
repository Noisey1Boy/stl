#include<iostream>
#include<vector>
using namespace std;

int main()
{
    vector<int> vec(6, 10); //vec(size, value);
    
    for(int value : vec)
    {
        cout << value << " ";
    }
    cout << endl;

    return 0;
}