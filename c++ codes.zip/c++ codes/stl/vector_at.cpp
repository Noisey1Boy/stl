#include<iostream>
#include<vector>
using namespace std;

int main()
{
    vector<int> vec; //size 0

    vec.push_back(1);
    vec.push_back(2);
    vec.push_back(3);
    vec.push_back(4);
    vec.push_back(5);
    vec.emplace_back(6);

    vec.pop_back();
    vec.pop_back();
    
    for(int value : vec)
    {
        cout << value << " ";
    }
    cout << endl;

    cout << "value at index 2 : " << vec.at(2) << " or " << vec[2] << endl;
    
    return 0;
}