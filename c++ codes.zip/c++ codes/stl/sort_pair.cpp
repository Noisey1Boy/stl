#include<iostream>
#include<algorithm>
#include<vector>
using namespace std;

int main()
{
    vector<pair<int, int>> vec = {{3 , 1} , {7 , 1} , {2 , 1} , {5 , 2}};

    sort(vec.begin() + 1, vec.begin() + 3); /*will sort elements from index1 to
                              index2 ,,, index3 will not be included */
    cout << "Sorted vector elements(index_1 to index_2) : \n";
    for(auto p : vec)
    {
        cout << p.first << " " << p.second << endl;
    }
   
    sort(vec.begin() , vec.end());
    
    cout << "Sorted vector elements(index_0 to index_5) : \n";
    for(auto p : vec)
    {
        cout << p.first << " " << p.second << endl;
    }

    return 0;
}