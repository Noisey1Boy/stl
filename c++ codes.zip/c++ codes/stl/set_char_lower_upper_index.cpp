#include<iostream>
#include<set>
using namespace std;

int main()
{
    //lower bound means minimmum or <=
    //upper bound means greater than or <
    set<char> s;

    s.insert('a');
    s.insert('c');
    s.insert('b');
    s.insert('b');
    s.insert('b');
    s.insert('c');
    s.insert('d');

    //distance(s.begin() , iterator) to show the index number by calculating the distance between begin() and iterator
    cout << "lower bound of s : " << *(s.lower_bound('b')) << " at index : " << distance(s.begin() , s.lower_bound('b')) << endl; //b
    cout << "upper bound of s : " << *(s.upper_bound('b')) << " at index : " << distance(s.begin() , s.upper_bound('b')) << endl; //c

    for(auto val : s)
    {
        cout << val << " ";
    }
    cout << endl;

    return 0;
    
}
