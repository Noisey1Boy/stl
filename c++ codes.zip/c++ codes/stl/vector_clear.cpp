#include<iostream>
#include<vector>
using namespace std;

int main()
{
    vector<int> vec = {1 , 2 , 3 , 4 , 5};

    vec.clear();
    
    cout << "values : ";
    
    for(int value : vec)
    {
        cout << value << " ";
    }
    cout << endl;

    cout << "size : " << vec.size() << endl;
    cout << "capacity : " << vec.capacity() << endl;
    
    return 0;
}