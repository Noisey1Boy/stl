#include<iostream>
#include<vector>
using namespace std;

int main()
{
    vector<int> vec; //size 0

    vec.push_back(1);
    vec.push_back(2);
    vec.push_back(3);
    vec.push_back(4);
    vec.push_back(5);

    for(int value : vec)
    {
        cout << value << " ";
    }
    
    return 0;
}