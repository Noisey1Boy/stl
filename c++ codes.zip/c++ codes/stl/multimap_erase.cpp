#include<iostream>
#include<map>
using namespace std;

int main()
{
    multimap<string , int> m;

    m.insert({"tv", 100});
    m.insert({"tv", 100});

    m.emplace("tv", 100);
    m.emplace("tv", 100);
    
    m.erase("tv");//sobgula tv key ke erase kore debe

    for(auto p : m)
    {
        cout << p.first << " " << p.second << endl;
    }

    return 0;
}