#include<iostream>

double getTotal(double prices[] , double size);

int main()
{
    double prices[] = {23, 43, 944, 53};
    double size = sizeof(prices)/sizeof(double);

    double total = getTotal(prices , size);

    std::cout << "Total : " << "$ " << total;

    return 0;
}
double getTotal(double prices[] , double size)
{
    double total;

    for(int i = 0; i < size; i++)
    {
        total += prices[i];
    }
    return total;
}