#include<iostream>

namespace first
{
    int x = 1;
}
namespace second
{
    int x = 2;
}

int main()
{
    using namespace first;
    
    std::cout << "x = " << x;
    
    /*emon using namespace e jei namespace er kotha bola hobe 
    output e shei output e dekhabe(ekhane <<first::x lekhar dorkar
    nei,jodi int_main er moddhe oi variable declare kora na thake)*/
    
    /*but jodi int_main er moddhe variable declare kora thake taile
    first namespace er output nite hole <<first::x; likhte hobe, jodi
    << x; emon lekha hoi taile int_main er moddhe je variable decclare 
    kora hoiche oita output dibe*/
    
    /* int-main e multiple using-namespace dewa jabena*/

    /*using namespace first diye <<second::x; likhle output ashbe seccond 
    namespace er */


    return 0;
}