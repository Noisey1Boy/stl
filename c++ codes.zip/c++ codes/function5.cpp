#include<iostream>

std::string concatStrings(std::string firstname , std::string lastname);

int main()
{
    std::string firstname = "Adnan";
    std::string lastname = "Abir";
    std::string fullname = concatStrings(firstname , lastname);

    std::cout << "Hello " << fullname;

    return 0;
}

std::string concatStrings(std::string string1 , std::string string2)
{
    return string1 + " " + string1;
}

