#include <iostream>
#include <vector>
#include <algorithm>  // for std::random_shuffle
#include <ctime>      // for std::time
//#include <cstdlib>    // for std::srand

int main() {
    std::vector<int> vec = {1, 2, 3, 4, 5};

    // Seed the random number generator
    std::srand(std::time(0));

    // Shuffle the vector
    std::random_shuffle(vec.begin(), vec.end());

    // Print shuffled vector
    std::cout << "Shuffled vector: ";
    for (int num : vec) {
        std::cout << num << " ";
    }
    // Possible output: Shuffled vector: 3 1 5 4 2

    return 0;
}