#include<iostream>
#include<algorithm>
using namespace std;

int main()
{
    string s = "asdf";
    cout <<"original" <<  s << endl;

    sort(s.begin() ,  s.end());
    cout << "sorted" << s << endl;

    cout << "reversed permutations :" ;

    sort(s.begin() , s.end() ,greater<int>());

    do
    {
        cout << s << " ";
    } while (prev_permutation(s.begin() , s.end()));

    return 0;
    
}