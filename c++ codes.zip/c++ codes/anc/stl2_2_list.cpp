#include<iostream>
#include<list>
using namespace std;

int main()
{
    list<int> numbers = {1 , 3 , 3 , 5};
    list<int> numbers2 = {2 , 4 , 6};

    //numbers.reverse();
    //numbers.sort();
    numbers.unique();
    if(numbers.empty())
    {
        cout << "empty";
    }
    //numbers.clear();
    numbers.merge(numbers2);
    for(int num : numbers)
    {
        cout << num << " ";
    }
    cout << endl;

   
    return 0;
}