#include<iostream>
#include<list>
#include<sstream>
#include<cctype>
#include<algorithm>
#include<iomanip>

using namespace std;

list<string> proccessDoc(const string &doc)
{
    list<string> words;
    stringstream ss(doc);
    string word;

    while(ss >> word)
    {
        transform(word.begin(), word.end(), word.begin(), ::tolower);

        word.erase(remove_if(word.begin(), word.end(), ::ispunct), word.end());
        words.push_back(word);
    }

    return words;
}

float jaccardsimilarity(const list<string> &doc1 ,const list<string> &doc2)
{
    list<string> intersection, unionlist;

    for(const auto &word : doc1)
    {
        if(find(doc2.begin(), doc2.end(), word) != doc2.end() &&
            find(intersection.begin() , intersection.end(), word) == intersection.end())
        {
            intersection.push_back(word);
        }
    }

    unionlist = doc1;
    for(const auto &word : doc2)
    {
        if(find(unionlist.begin(), unionlist.end(), word) == unionlist.end())
        {
            unionlist.push_back(word);
        }
    }

    if(unionlist.empty()) return 1.0;

    return static_cast<float> (intersection.size()) / unionlist.size();
}

int main()
{

    string doc1 = "Data is the new oil of the digital economy";
    string doc2 = "Data is a new oil";
    //string doc1 = "";
    //string doc2 = "";
    
    list<string> words1 = proccessDoc(doc1);
    list<string> words2 = proccessDoc(doc2); 

    float similarity = jaccardsimilarity(words1, words2);
    
    cout << fixed << setprecision(3);
    cout << "Jaccard similarity: " << similarity << endl;  // Expected: ~0.444

    return 0;
}