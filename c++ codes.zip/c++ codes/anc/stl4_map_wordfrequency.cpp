#include<iostream>
#include<map>
#include<sstream>
#include<algorithm>
using namespace std;

int main()
{
    string input = "learning to code is learning to create and innovate";

    map<string, int> wordFrequency;
    stringstream ss(input);
    string word;

    while(ss >> word)
    {
        transform(word.begin(), word.end(), word.begin(), ::tolower);

        wordFrequency[word]++;
    }

    for(auto &pair : wordFrequency)
    {
        cout << pair.first << "  " << pair.second << endl;
    }

    return 0;
}
