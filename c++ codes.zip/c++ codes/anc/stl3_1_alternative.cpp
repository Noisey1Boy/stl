#include <iostream>
#include<sstream>
#include <vector>
#include<algorithm>
using namespace std;

string reverseWordsWithoutStack(string s) {
    stringstream ss(s);
    vector<string> words;
    string word;
    
    while (ss >> word) {
        words.push_back(word);
    }
    
    reverse(words.begin(), words.end());
    
    string reversed;
    for (const auto& w : words) {
        reversed += w + " ";
    }
    
    // Remove trailing space
    if (!reversed.empty()) {
        reversed.pop_back();
    }
    
    return reversed;
}

int main()
{
    string input = "Technical Interview Preparation";
    string output = reverseWordsWithoutStack(input);

    cout << "input : " << input << endl;
    cout << "output : " << output << endl;

    return 0;
}