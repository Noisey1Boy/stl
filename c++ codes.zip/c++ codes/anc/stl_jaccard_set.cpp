#include<iostream>
#include<set>
#include<sstream>
#include<iomanip>
#include<algorithm>
using namespace std;

set<string> proccessSet(const string &doc)
{
    set<string> words;
    stringstream ss(doc);
    string word;

    while (ss >> word)
    {
        transform(word.begin(), word.end(), word.begin(), ::tolower);
        words.insert(word);
    }
    return words;
}

double jaccardSimilarity(const set<string> &set1, const set<string> &set2)
{
    set<string> intersection;
    set_intersection(set1.begin(), set1.end(),
                    set2.begin(), set2.end(),
                    inserter(intersection, intersection.begin()));

    set<string> unionSet;
    set_union(set1.begin(), set1.end(),
                    set2.begin(), set2.end(),
                    inserter(unionSet, unionSet.begin()));

    if(unionSet.empty()) return 1.0;

    return static_cast<double> (intersection.size()) / unionSet.size();
}   
int main()
{
    string doc1 = "Data is the new oil of the digital economy";
    string doc2 = "Data is a new oil";

    set<string> set1 = proccessSet(doc1);
    set<string> set2 = proccessSet(doc2);


    double similarity = jaccardSimilarity(set1, set2);

    cout << fixed << setprecision(3);
    cout << "jac sim: " << similarity << endl;

    return 0;

}
