#include<iostream>
#include<list>
using namespace std;

int main()
{
    list<int> numbers = {1, 2, 5, 3, 6};

    numbers.pop_back();
    numbers.pop_front();

    for(int number : numbers)
    {
        cout << number << " ";
    }
    cout << endl;

    numbers.push_front(0);
    numbers.push_back(9);
    numbers.push_front(8);
    numbers.push_back(7);

    for(int number : numbers)
    {
        cout << number << " ";
    }
    cout << endl;

    return 0;
}