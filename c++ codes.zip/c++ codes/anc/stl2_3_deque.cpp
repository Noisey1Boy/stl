#include<iostream>
#include<deque>
using namespace std;

int main()
{
    deque<int> nums = {1 , 3 , 5};

    cout << "initial deque : ";
    for(int num : nums)
    {
        cout << num << " ";
    }
    cout << endl;

    nums.push_back(4);
    nums.push_front(0);

    cout << "middle deque : ";
    for(int num : nums)
    {
        cout << num << " ";
    }
    cout << endl;

    nums[0] = 9;
    nums.at(1) = 8;
    
    cout << "final deque : ";
    for(int num : nums)
    {
        cout << num << " ";
    }
    cout << endl;
  
    return 0;
}