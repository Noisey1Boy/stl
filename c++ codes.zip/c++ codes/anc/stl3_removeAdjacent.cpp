#include<iostream>
#include<stack>

using namespace std;

string removeAdjDuplicate(string input)
{
    stack<char> st;

    for(char c : input)
    {
        if(!st.empty() && st.top() == c) 
        {
            st.pop();
        }
        else
        {
            st.push(c);
        }
    }

    string result;
    while(!st.empty())
    {
        result = st.top() + result;
        st.pop();
    }

    return result;
}

int main()
{
    cout << removeAdjDuplicate("azxxzy") << endl;
    cout << removeAdjDuplicate("aaccbb") << endl;
    cout << removeAdjDuplicate("csecu") << endl;

    return 0;
}