#include<iostream>
#include<vector>
#include<numeric>
using namespace std;

int main()
{
    vector<int> v = {1, 2, 3, 2};

    cout << "vector con:";
    for(int c : v)
    {
        cout << c << " ";
    }

    cout << endl;

    cout << "sum : " << accumulate(v.begin() , v.end() , 0) << endl;
    cout << "inner product : "<< inner_product(v.begin() , v.end(), v.begin(),  0) << endl;

    //modified
    cout << "sum : " << accumulate(v.begin() , v.end() , 1 , multiplies<int>()) << endl;
    return 0;
}