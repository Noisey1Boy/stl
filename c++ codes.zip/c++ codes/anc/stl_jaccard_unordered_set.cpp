#include <iostream>
#include <list>
#include <sstream>
#include <cctype>
#include <algorithm>
#include <iomanip>
#include <unordered_set>

using namespace std;

list<string> proccessDoc(const string &doc) {
    list<string> words;
    stringstream ss(doc);
    string word;

    while (ss >> word) {
        transform(word.begin(), word.end(), word.begin(), ::tolower);
        word.erase(remove_if(word.begin(), word.end(), ::ispunct), word.end());
        words.push_back(word);
    }
    return words;
}

float jaccardsimilarity(const list<string> &doc1, const list<string> &doc2) {
    unordered_set<string> set1(doc1.begin(), doc1.end());
    unordered_set<string> set2(doc2.begin(), doc2.end());

    unordered_set<string> intersection;
    for (const auto &word : set1) {
        if (set2.count(word)) {
            intersection.insert(word);
        }
    }

    unordered_set<string> unionSet = set1;
    for (const auto &word : set2) {
        unionSet.insert(word);
    }

    if (unionSet.empty()) return 0.0f;
    return static_cast<float>(intersection.size()) / unionSet.size();
}

int main() {
    string doc1 = "Data is the new oil of the digital economy";
    string doc2 = "Data is a new oil";

    list<string> words1 = proccessDoc(doc1);
    list<string> words2 = proccessDoc(doc2);

    float similarity = jaccardsimilarity(words1, words2);
    
    cout << fixed << setprecision(3);
    cout << "Jaccard similarity: " << similarity << endl;  // Now correctly outputs 0.444

    return 0;
}