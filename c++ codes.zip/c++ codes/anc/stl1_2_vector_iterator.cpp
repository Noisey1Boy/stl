#include<iostream>
#include<vector>
using namespace std;

int main()
{
    vector<int> vec;

    vec.push_back(3);
    vec.push_back(7);
    vec.push_back(1);

    cout << "content of vector : ";

    for(auto it = vec.begin(); it != vec.end(); it++)
    {
        cout << *it << " ";
    }

    return 0;

}