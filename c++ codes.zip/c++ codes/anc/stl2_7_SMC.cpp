#include<iostream>
#include<iomanip>
using namespace std;

void calculate_smc(const string &p , const string &q)
{
    int f00 = 0, f01 = 0, f10 = 0, f11 = 0;

    if(p.length() != q.length())
    {
        cout << "Error: Binary strings must be of equal length.\n";
        return;
    }

    for(size_t i = 0; i < p.length(); i++)
    {
        if(p[i] == '0' && q[i] == '0') f00++;
        else if(p[i] == '0' && q[i] == '1') f01++;
        else if(p[i] == '1' && q[i] == '0') f10++;
        else if(p[i] == '1' && q[i] == '1') f11++;

        else 
        {
            cout << "Error: Invalid binary digit at position " << i << endl;
            return;
        }
    }

    double smc = static_cast<double> (f11 + f00) / (f01 + f10 + f11 + f00);

    cout << "f00 = " << f00 << endl;
    cout << "f01 = " << f01 << endl;
    cout << "f10 = " << f10 << endl;
    cout << "f11 = " << f11 << endl;
    cout << fixed << setprecision(2);
    cout << "SMC = " << smc << endl;
}
int main()
{
    string p , q;

    cout << "Enter first binary string : ";
    cin >> p;

    cout << "Enter second binary string : ";
    cin >> q;

    calculate_smc(p , q);

    return 0;
}