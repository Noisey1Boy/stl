#include<iostream>
#include<list>
#include<algorithm>
using namespace std;

int main()
{
    list<string> words1 = {"orange" , "banana" , "apple" , "pineapple"};
    list<string> words2 = {"mango" , "apple" , "jackfruit" , "banana" , "orange"};
    list<string> common_words;

    words1.sort();
    words2.sort();

    set_intersection(words1.begin(),words1.end(),
                     words2.begin(), words2.end(),
                     back_inserter(common_words));
                    
    cout << "Common Words : ";
    for(string words : common_words)
    {
        cout << words << " ";
    }
    cout << endl;

    return 0;
}   