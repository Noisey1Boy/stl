#include<iostream>
#include<stack>
#include<sstream>
using namespace std;

string reverseSentence(string s)
{
    stack<string> st;
    stringstream ss(s);
    string words;

    while(ss >> words)
    {
        st.push(words);
    }

    string reversed;
    while(!st.empty())
    {
        reversed += st.top();
        st.pop();

        if(!st.empty())
        {
            reversed += " ";
        }
    }
        return reversed;
}

int main()
{
    string input = "Technical Interview Preparation";
    string output = reverseSentence(input);

    cout << "input : " << input << endl;
    cout << "output : " << output << endl;

    return 0;
}