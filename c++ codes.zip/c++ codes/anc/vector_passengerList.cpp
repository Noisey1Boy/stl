#include<iostream>
#include<vector>
using namespace std;

class passenger
{
    private :
        string name;
        int seatNumber;
    
    public :
        passenger(string n = "unknown", int s = 0): name(n) , seatNumber(s) {}
        
    void display()
    {
        cout << "passenger : " << name << " , seat : " << seatNumber << endl;
    }
};
int main()
{
    vector<passenger> passengerList(20);

    passengerList[0] = passenger();
    passengerList[1] = passenger("bob");
    passengerList[2] = passenger("charlie" , 20);

    cout << "passenger list : \n";
    for(int i = 0; i < 4; i++)
    {
        passengerList[i].display();
    }
    passengerList[5].display();

    cout << "\nvector size : " << passengerList.size() << " passengers" << endl;

    return 0;
}