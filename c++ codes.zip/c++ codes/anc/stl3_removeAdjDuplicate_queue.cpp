#include<iostream>
#include<queue>
using namespace std;

string removeAdjDup(const string &s)
{
    queue<char> qu;

    for(char c : s)
    {
        if(!qu.empty() && qu.back() == c)
        {
            qu.pop();
        }
        else
        {
            qu.push(c);
        }
    }

    string result;
    while(!qu.empty())
    {
        result += qu.front();
        qu.pop();
    }

    return result;
}

int main()
{
    cout << "Output : " << removeAdjDup("axzzxy") << endl;
    cout << "Output : " << removeAdjDup("aabbcc") << endl;

    return 0;

}