#include <iostream>
using namespace std;

int main() {
    // condition ? expression1 : expression2;

    int grade = 50;
    grade >= 60 ? cout << "You pass!\n" : cout << "You fail!\n";
    
    int number;
    cout << "enter number : ";
    cin >> number;
    cout << (number % 2 ? "ODD\n" : "EVEN\n");
    
    bool hungry = true;
    // hungry ? std::cout << "You are hungry" : std::cout << "You are full";
    
    cout << (hungry ? "You are hungry" : "You are full");
    
    return 0;
}