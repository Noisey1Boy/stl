#include<iostream>
#include<fstream>
#include<limits>
using namespace std;

int main()
{
    string name;
    int age;

    ofstream student_file;

    student_file.open("student_details.txt" , ios::app);

    for(int i = 0; i < 4; i++)
    {
        cout << "Enter your name : ";
        getline(cin, name);
        student_file << name << "\t";
    
        cout << "Enter your age :";
        cin >> age;
        student_file << age << endl;
    
        cin.ignore(numeric_limits<streamsize>::max() , '\n');    
    }

    student_file.close();

    cout << "Data was stored!\n";

    return 0;
}