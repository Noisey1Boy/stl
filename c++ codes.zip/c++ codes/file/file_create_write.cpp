#include<iostream>
#include<fstream>
using namespace std;

int main()
{
    ofstream file;

    file.open("file_create.txt");

    file << "I am Rangan. I am 20 years old.\n"; 
    
    file.close();
    
    cout << "Data is stored!\n";
    
    return 0;
}