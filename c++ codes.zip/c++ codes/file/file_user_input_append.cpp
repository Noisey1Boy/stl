#include<iostream>
#include<fstream>
using namespace std;

int main()
{
    string name;

    ofstream file;

    //file.open("student.txt" , ios::out|ios::app); //need to use it when using fstream as datatype
    //or 
    file.open("student.txt" , ios::app); //better to use while using ofstream datatype 

    cout << "Enter your name : ";
    getline(cin,name);
    file << "Welcome " << name << endl;

    file.close();

    cout << "Data is stored\n";
    
    return 0;
}