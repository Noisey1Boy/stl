#include<iostream>
#include<limits>
#include<ctime>
using namespace std;

char getPlayerChoice();
char getComputerChoice();
void showChoice(char choice);
void chooseWinner(char player , char computer);

int main()
{
    char playerChoice;
    char computer;
    char playAgain;
    do
    {
        playerChoice = getPlayerChoice();
        if(playerChoice == 'e')
        {
            cout << "Exiting game!\n";
            return 0;
        }
        cout << "Your choice : ";
        showChoice(playerChoice);
    
        computer = getComputerChoice();
        cout << "Computer choice : ";
        showChoice(computer);
    
        chooseWinner(playerChoice , computer);
        
        cout << "Do you want to play again? (y/n) : ";
        cin >> playAgain;
    
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max() , '\n');
        
        playAgain = tolower(playAgain);
       
    } while (playAgain == 'y');
    
    return 0;
}

char getPlayerChoice()
{
    char choice;

    do
    {   
        cout << "\n******************************\n";
        cout << "Rock - Paper - Scissors Game!!\n";
        cout << "******************************\n";
        cout << "Choose one of the following :\n";
        cout << "'r' for rock\n";
        cout << "'p' for paper\n";
        cout << "'s' for scissor\n";
        cout << "'e' to exit\n";
        cout << "Enter your choice : ";
        cin >> choice;
    
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max() , '\n');
        
        tolower(choice);
        
        if(choice != 'r' && choice != 'p' && choice != 's' && choice != 'e')
        {
            cout << "Invalid choice!!\n";
        }

    }
    while(choice != 'r' && choice != 'p' && choice != 's' && choice != 'e');
    
    return choice;

}
char getComputerChoice()
{
    srand(time(NULL));

    int num = rand() % 3 + 1;

    switch(num)
    {
        case 1 : return 'r';
        case 2 : return 'p';
        case 3 : return 's';
    }
}
void showChoice(char choice)
{
    switch (choice)
    {
    case 'r':
        cout << "rock\n";
        break;
    case 'p':
        cout << "paper\n";
        break;
    case 's':
        cout << "scissors\n";
        break;
    }
}
void chooseWinner(char player , char computer)
{
    switch (player)
    {
    case 'r':
        if(computer == 'r')
        {
            cout << "It's a tie!\n";
        }
        else if(computer == 'p')
        {
            cout << "You lose!\n";
        }
        else
        {
            cout << "You win!\n";
        }
        break;
    case 'p':
        if(computer == 'r')
        {
            cout << "You win!\n";
        }
        else if(computer == 'p')
        {
            cout << "It's a tie!\n";
        }
        else
        {
            cout << "You lose!\n";
        }
        break;
    case 's':
        if(computer == 'r')
        {
            cout << "You lose!\n";
        }
        else if(computer == 'p')
        {
            cout << "You win!\n";
        }
        else
        {
            cout << "It's a tie!\n";
        }
        break;
    }
}
