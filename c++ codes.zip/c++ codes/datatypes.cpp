#include<iostream>
int main()
{
    int age = 21;
    int days = 7.5;

    std::cout << '\n';//eta diye faka line output niewa jabe
    std::cout << age << '\n';
    std::cout << days << '\n';/*integer e 7.5 er moto decimal 
                              with fractional part thakle output
                              e sudhu decimal point er ager purno
                            shonkha show korbe*/
    std::cout << '\n';


    //double(number including decimal)
    double price = 10.99;
    double gpa = 2.5;

    std::cout << price << '\n';
    std::cout << gpa << '\n';
    std::cout << '\n';


    //single character 
    char grade = 'A';
    char initial = 'BC'; /* char datatype sudhu ekta character 
                          store korte pare, ek er cheye beshi 
                          character dile last character ta outpuut 
                          e show korbe*/
    char currency = '$'; //char datatype $,%,&,^ eulao store kore out dei
    std::cout << grade << '\n';
    std::cout << initial << '\n';
    std::cout << currency << '\n';
    std::cout << '\n';


    //boolean (true or false)
    bool student = false; //false hoile output 0
    bool power = true;    //true hoile output 1

    std::cout << student << '\n';
    std::cout << power << '\n';
    std::cout << '\n';

    /*string(objects that represent a sequence of text)
    strings are provided from the standard namespace, to decalre
    a string we type std::string variablename = "name";  */
    std::string name = "Rangan";
    std::string team = "Argentina";
    std::string club = "Barcelona visca barca 5";//space and number soho sentence o output dite pare

    std::cout << name << '\n';
    std::cout << team << '\n';
    std::cout << club << '\n';
    std::cout << "Hello World" << '\n';//ebhabe directly string output newa jai
    std::cout << "Vamos " << team << '\n';/*ebhabe directly string output newar por
                                          variable name diye directly lekha string er
                                          por oi variable output pawa jai
                                          and pay atention to spacing,
                                          ebhabe output newar shomoy  */
    std::cout << "You are " << age << " years old" << '\n';//ebhabeo output newa jabe
    std::cout << '\n';

    return 0;
}