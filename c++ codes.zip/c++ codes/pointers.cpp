#include<iostream>

int main()
{
    std::string name = "rangan";
    int age = 31;
    std::string freePizzas[5] = {"pizza", "burger", "cake", "coke"};

    std::string *pName = &name;
    int *pAge = &age;
    std::string *pFreePizzas = freePizzas;

    std::cout << *pName << '\n';
    std::cout << *pAge << '\n';
    std::cout << *pFreePizzas << '\n';

    return 0;

}