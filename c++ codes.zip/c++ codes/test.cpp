#include<iostream>
#include<stack>
using namespace std;

string processString(const string &s)
{
    stack<char> st;

    for(char c : s)
    {
        if(c == '#')
        {
            if(!st.empty())
            {
                st.pop();
            }
        }
        else
        {
            st.push(c);

        }
    }
    string result;
    while(!st.empty())
    {
        result = st.top() + result;
        st.pop();
    }

    return result;
}

bool backspaceCompare(string s1 , string s2)
{
    return processString(s1) == processString(s2);
}

int main()
{
    cout << boolalpha;

    string s1 = "geee#e#ks";
    string s2 = "gee##eeks";
    cout << "input : s1 = \"" << s1 << "\" , s2 = \"" << s2 << "\"" << endl << endl;
    cout << "output : " << backspaceCompare(s1 , s2) << endl << endl;
    
    s1 = "equ#ual";
    s2 = "ee#quaal";
    cout << "input : s1 = \"" << s1 << "\" , s2 = \"" << s2 << "\"" << endl << endl;
    cout << "output : " << backspaceCompare(s1 , s2) << endl << endl;

    return 0;
}