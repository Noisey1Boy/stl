#include<iostream>
#include<limits>
using namespace std;

int main()
{
    int size; 
    cout << "enter size : ";
    cin >> size;

    cin.clear();
    cin.ignore(numeric_limits<streamsize>::max() , '\n');

    string foods[size];
    
    string temp;

    for(int i = 0; i < size; i++)
    {
        cout << "Enter a food you like or 'e' to exit #" << i + 1 << " : ";
        getline(cin , temp);

        if(temp == "e")
        {
           break;
        }
        else
        {
            foods[i] = temp;
        }
        
    }

    cout << "You like the following food :\n";
    for(int i = 0; !foods[i].empty(); i++)
    {
        cout << foods[i] << endl;
    }
    return 0;
}
