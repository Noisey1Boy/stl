#include<iostream>

int main()
{
    std::cout << "I like pizza!" << std::endl;
    std::cout << "It's really good!" <<'\n'; //<< std::endl; er poriborte <<'\n'; use kora jabe
    std::cout << "I eat pizza quie often!" << std::endl;
    return 0;
}