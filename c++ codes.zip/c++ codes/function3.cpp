#include<iostream>

void happybirthday(std::string name);

int main()
{
    std::string name = "Rangan";

    happybirthday(name);
    happybirthday(name);
    happybirthday(name);

    return 0;

}

void happybirthday(std::string name)
{
    std::cout << "happy birthday to " << name << '\n';
    std::cout << "happy birthday to " << name << '\n';
    std::cout << "happy birthday dear " << name << '\n';
    std::cout << "happy birthday to " << name << '\n';
    std::cout << '\n';
}