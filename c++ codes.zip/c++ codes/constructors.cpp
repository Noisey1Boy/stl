#include<iostream>

class Student
{
    public:
        std::string name;
        int age;
        double gpa;

    //    Student(std::string name, int age, double gpa)
    //    {
    //        this->name = name;
    //        this->age = age;
    //        this->gpa = gpa;
    //    } 
    //  OR,,,,
    Student(std::string x, int y, double z)
    {
        name = x;
        age = y;
        gpa = z;
    }
};

int main()
{
    Student student1("Spongebob" , 36 , 3.4);
    Student student2("Patrick" , 23 , 3.2);

    std::cout << student1.name << '\n';
    std::cout << student1.age << '\n';
    std::cout << student1.gpa << '\n';

    std::cout << student2.name << '\n';
    std::cout << student2.age << '\n';
    std::cout << student2.gpa << '\n';

    return 0;
    
}