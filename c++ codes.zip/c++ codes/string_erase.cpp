#include<iostream>

int main()
{
    std::string name;

    std::cout << "Enter your name : ";
    std::getline(std::cin , name);

    std::cout << name << '\n';

    name.erase(0 , 3); //string no 0 to 2 will be erased
                       //string no 3 won't be erased
                       //starting is included but ending is not
    std::cout << name;

    return 0;

}