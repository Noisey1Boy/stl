#include<iostream>
using namespace std;
int main()
{
    string name = "Bro";

    cout << "Hello " << name;

    return 0;
}