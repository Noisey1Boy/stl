#include<iostream>

void happybirthday()
{
    std::cout << "happy birthday to you\n";
    std::cout << "happy birthday to you\n";
    std::cout << "happy birthday dear you\n";
    std::cout << "happy birthday to you\n\n";
}

int main()
{
    happybirthday();
    happybirthday();
    happybirthday();

    return 0;

}