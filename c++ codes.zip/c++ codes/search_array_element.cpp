#include<iostream>

double searchArray(double array[] , double element , double size);

int main()
{
    double numbers[] = {23, 43, 944, 53};
    double size = sizeof(numbers)/sizeof(double);
    double index;
    double myNum;

    std::cout << "Enter element to search for : ";
    std::cin >> myNum;

    index = searchArray(numbers, myNum , size );

    if(index != -1)
    {
        std::cout << myNum << " is at index " << index;
    }
    else
    {
        std::cout << myNum << " is not in the array!!";
    }

    return 0;
}
double searchArray(double array[] , double element , double size )
{
    for(int i = 0; i < size; i++)
    {
        if(array[i] == element)
        {
            return i;
        }
    }
    return -1;
}