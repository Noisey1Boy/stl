#include<iostream>
int main()
{
    std::string name;
    int age;

    std::cout << "What's your full name?" << '\n';
    std::getline(std::cin, name);// get line diye space soho input newa jai

    std::cout << "What's your age?" << '\n';
    std::cin >>age;
    
    std::cout << "Hello " << name << '\n';
    std::cout << "You are " << age << " years old";

    return 0;

}