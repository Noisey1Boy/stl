#include<iostream>

namespace first
{
    int x = 1;
}

namespace second
{
    int x = 2;
}

int main()
{

    /*Namespace = provides a solutionn for preventing name conflicts
    in large projects. Each entity needs a unique name.
    A namespace allows for identically named entities
    as long as the amespaces are different.  */

    int x = 0;

    std::cout << "local version of x = " << x << '\n';
                                                /*specically jodi kon
                                                x er value bole dewa na
                                                hoi taile local version 
                                                output dibe*/
    std::cout << "Version of x within the first namespace = " << first::x << '\n';
                                                /*namespace er kono variable er 
                                                output newar jonno namespace er 
                                                name::variable_name nite hobe*/
    std::cout << "Version of x within the second namespace = " << second::x << '\n';                                            




    return 0;
}