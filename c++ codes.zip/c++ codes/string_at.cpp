#include<iostream>

int main()
{
    std::string name;

    std::cout << "Enter your name : ";
    std::getline(std::cin , name);

    std::cout << name << '\n';

    std::cout << name.at(7);

    return 0;

}